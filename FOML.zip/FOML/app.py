import streamlit as st
import pandas as pd
import joblib

# Load saved model and tools
model = joblib.load("fraud_model.pkl")
scaler = joblib.load("scaler.pkl")
label_encoders = joblib.load("label_encoders.pkl")

# Streamlit page title
st.set_page_config(page_title="Mediclaim Fraud Detector", layout="centered")
st.title("🩺 Mediclaim Fraud Detection")
st.markdown("Enter the details of the claim below to predict whether it is **fraudulent** or **legitimate**.")

# Helpful info
st.info("ℹ️ **Diagnosis Code Reference:**\n"
        "- `A01`: Infectious disease\n"
        "- `B02`: Minor illness\n"
        "- `C03`: Chronic condition\n"
        "- `D04`: Emergency care\n"
        "- `E05`: Surgery")

# Layout with 2 columns
col1, col2 = st.columns(2)

with col1:
    age = st.slider("Patient Age", 18, 80, 30)
    hospital_type = st.selectbox("Hospital Type", ['govt', 'private', 'semi-private'],
                                 help="Type of hospital where treatment was taken")
    diagnosis_code = st.selectbox("Diagnosis Code", ['A01', 'B02', 'C03', 'D04', 'E05'],
                                  help="Medical code representing treatment category")
    has_chronic_disease = st.selectbox("Has Chronic Disease?", [0, 1], help="1 = Yes, 0 = No")

with col2:
    claim_amount = st.number_input("Claim Amount (₹)", min_value=1000, max_value=200000, step=1000)
    days_admitted = st.slider("Days Admitted", 1, 30, 5)
    doctor_visits = st.slider("Doctor Visits", 1, 15, 2)
    num_previous_claims = st.slider("Previous Claims Made", 0, 10, 1)

# Predict button
if st.button("Check for Fraud"):
    # Prepare input data
    input_data = pd.DataFrame([{
        "claim_amount": claim_amount,
        "age": age,
        "hospital_type": label_encoders['hospital_type'].transform([hospital_type])[0],
        "diagnosis_code": label_encoders['diagnosis_code'].transform([diagnosis_code])[0],
        "days_admitted": days_admitted,
        "doctor_visits": doctor_visits,
        "num_previous_claims": num_previous_claims,
        "has_chronic_disease": has_chronic_disease
    }])

    # Scale
    input_scaled = scaler.transform(input_data)

    # Predict
    prediction = model.predict(input_scaled)[0]
    prob = model.predict_proba(input_scaled)[0][1]

    # Result
    st.markdown("---")
    if prediction == 1:
        st.error(f"⚠️ This claim is predicted to be **FRAUDULENT**.\n\n🔍 Probability: `{prob:.2f}`")
    else:
        st.success(f"✅ This claim is predicted to be **LEGITIMATE**.\n\n🔍 Probability: `{1 - prob:.2f}`")
